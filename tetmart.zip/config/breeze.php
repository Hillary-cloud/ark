<?php

return [
    // ...

    'features' => [
        // ...
        'email_verification' => true,
    ],

    // ...
];