<base href="/public">

<?php $__env->startSection('content'); ?>

    <style>
        .other-image {
            cursor: pointer;
        }

        /* CSS for the modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 9999;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            justify-content: center;
            align-items: center;
        }

        .modal-image {
            max-width: 80%;
            max-height: 80%;
            padding-top: 100px;
        }

        /* CSS to center the modal image */
        .modal-image {
            display: block;
            margin: auto;
        }

        #social-links ul li {
            display: inline-block;
            margin-top: 15px;
        }

        #social-links ul li a {
            padding: 5px;
            margin: 2px;
            font-size: 20px;
            color: rgb(46, 41, 114);
            background-color: #ccc;
        }

        #social-links ul li a:hover {
            background-color: rgb(46, 41, 114);
            color: white;
        }
    </style>

    <div class="container my-5">
        <div class="card my-2">
            <div class="d-flex justify-content-between p-2">
                <?php if($advert->lodge_id !== null): ?>
                    <h2 class="fw-bold"><?php echo e(ucfirst($advert->lodge->name)); ?></h2>
                <?php else: ?>
                    <h2 class="fw-bold"><?php echo e(ucfirst($advert->service->name)); ?></h2>
                <?php endif; ?>

                <p class=""><a href="javascript:history.back()" class="text-decoration-none">
                        < Back</a><span class="text-muted">/<?php echo e(ucfirst($advert->school_area->name)); ?></span></p>
            </div>
        </div>
        <img src="<?php echo e(asset($advert->cover_image)); ?>" class="img-fluid mx-auto d-block"
            style="width: 100%; object-fit:cover; height:500px" alt="">
        <h4 class=" fw-bold text-success mt-4">More</h4>
        <div class="row align-items-start mb-5">
            <?php $__currentLoopData = $advert->other_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-3 col-sm-3 col-3">
                    <img src="<?php echo e(asset($images)); ?>" style="width:100%; object-fit:cover; height: 15vh;"
                        class="img-fluid other-image" alt="">

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <?php if($advert->lodge_id !== null): ?>
            <h1 class="display-4"><?php echo e(ucfirst($advert->lodge->name)); ?> for rent</h1>
        <?php else: ?>
            <h1 class="display-4"><?php echo e(ucfirst($advert->service->name)); ?></h1>
        <?php endif; ?>

        <div class="card p-4 shadow-lg">
            <h2 class="fw-bolder text-success">Quick Summary</h2>
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6 col-12 mb-2 ">
                    <?php if($advert->lodge_id !== null): ?>
                        <p><span class="">Price -</span> &#8358 <?php echo e(number_format($advert->combined_price)); ?> per annum
                        </p>
                        <?php if($advert->negotiable == true): ?>
                            <p class="text-muted fst-italic"> Price is negotiable</p>
                        <?php else: ?>
                            <p class="text-muted fst-italic"> Price is not negotiable</p>
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if($advert->on_contact == true): ?>
                            <p class="text-muted fst-italic"> Price is on contact</p>
                        <?php else: ?>
                            <p><span class="">Price -</span> &#8358 <?php echo e(number_format($advert->combined_price)); ?></p>
                        <?php endif; ?>
                    <?php endif; ?>

                    <p><span class="">School Area -</span> <?php echo e(ucfirst($advert->school_area->name)); ?></p>
                    <p><span class="">School -</span> <?php echo e(ucfirst($advert->school->name)); ?></p>
                    <p><span class="">State -</span> <?php echo e(ucfirst($advert->location->state)); ?></p>
                    <p><span class="">Time Listed -</span> <?php echo e($advert->created_at->diffForHumans()); ?></p>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                    <h4 class="fw-bold">Description</h4>
                    <p><?php echo e(ucfirst($advert->description)); ?>

                    </p>
                    <?php if(auth()->guard()->check()): ?>
                        <h5 class="bg-success rounded-pill text-center p-2 text-light"> <?php echo e($advert->phone_number); ?></h5>
                        <h5 class="bg-primary rounded-pill text-center p-2 text-light">Seller -
                            <?php echo e(ucfirst($advert->seller_name)); ?></h5>
                    <?php else: ?>
                        <a href="<?php echo e(url('login')); ?>" class="text-center btn btn-success btn-lg fw-bold rounded-pill"><i
                                class="bi bi-telephone"></i> CONTACT SELLER</a>
                    <?php endif; ?>
                    <div class="d-flex">
                        <p style="font-size:20px; margin-top:15px"><i class="bi bi-share"
                                style="font-size:20px; margin-top:15px"></i> Share on</p>
                        <?php echo $shareButton; ?>

                    </div>
                </div>
            </div>
        </div>

        <div class="card p-4 m-3 shadow-sm">
            <h4>Safety tips</h4>
            <ul>
                <li>Don't pay in advance, including for delivery</li>
                <li>Meet the seller at a safe public place</li>
                <li>Inspect the property and ensure it's exactly what you want</li>
                <li>Only pay when you are satisfied</li>
            </ul>
        </div>
        <?php if($advert->lodge_id !== null): ?>
            <a href="<?php echo e(route('postLodge')); ?>" class="btn btn-outline-success btn-light fw-bold mb-4">POST LODGE SIMILAR TO
                THIS</a>
        <?php else: ?>
            <a href="<?php echo e(route('postService')); ?>" class="btn btn-outline-success btn-light fw-bold mb-4">POST SERVICE
                SIMILAR TO THIS</a>
        <?php endif; ?>
        <div class="card p-3 my-3 mb-4">
            <h2 class="fw-bolder text-warning">Related Ads</h2>
        <div class="row ">
            <?php $__currentLoopData = $adverts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-4 col-sm-6 col-12 my-4">
                            <a href="<?php echo e(route('property-detail', $advert->uuid)); ?>" class="text-decoration-none">
                                <div class="card shadow-lg">
                                    <img src="<?php echo e(asset($advert->cover_image)); ?>" class="card-img-top w-100"
                                        style="object-fit: cover; height:25vh" alt="">
                            </a>
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <?php if($advert->lodge_id !== null): ?>
                                    <h4 class="card-tittle fw-bold text-dark "><?php echo e(ucfirst($advert->lodge->name)); ?></h4>
                                    <?php else: ?>
                                    <h4 class="card-tittle fw-bold text-dark "><?php echo e(ucfirst($advert->service->name)); ?></h4>
                                    <?php endif; ?>
                                    
                                    <?php if(auth()->guard()->check()): ?>
                                        <i class="bi bi-bookmark" style="font-size: 25px"></i>
                                    <?php endif; ?>

                                </div>

                                <div class="d-flex justify-content-between">
                                    <?php if($advert->lodge_id !== null): ?>
                                    <p class="card-text fw-bold bg-success p-2 rounded-pill text-light w-52 text-center">
                                        &#8358 <?php echo e(number_format($advert->combined_price)); ?></p>
                                    <?php else: ?>
                                    <?php if($advert->on_contact == true): ?>
                                    <p class="text-muted fst-italic"> Price is on contact</p>
                                <?php else: ?>
                                    <p><span class="">Price -</span> &#8358 <?php echo e(number_format($advert->combined_price)); ?></p>
                                <?php endif; ?>
                                    <?php endif; ?>
                                    
                                    <p class="card-text "><small
                                            class="text-muted"><?php echo e(ucfirst($advert->location->state)); ?></small></p>
                                </div>

                                <div class="d-flex justify-content-between mb-0">
                                    <p class="card-text fw-bold text-dark"><?php echo e(ucfirst($advert->school->name)); ?></p>
                                    <p class="card-text text-dark"><?php echo e(ucfirst($advert->school_area->name)); ?></p>
                                </div>
                                <div class="d-flex justify-content-between">
                                    <p class="card-text "><small class="text-muted">Listed
                                            <?php echo e($advert->created_at->diffForHumans()); ?></small></p>
                                    <i class="bi bi-eye"> <?php echo e($advert->view_count); ?></i>
                                </div>
                            </div>
                        </div>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    </div>

    <script src="<?php echo e(asset('js/image_modal.js')); ?>"></script>

    <!-- Modal for displaying large image -->
    <div class="modal">
        <img src="" class="modal-image" alt="Other Image">
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\laravel\ark-project\resources\views/detail.blade.php ENDPATH**/ ?>