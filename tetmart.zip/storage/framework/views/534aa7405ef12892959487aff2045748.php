<base href="/public">

<?php $__env->startSection('content'); ?>

    <div class="container-fluid p-5">
        <div class="card w-100 shadow-sm p-2">
            <div class="d-flex justify-content-between">
                <h3>Draft</h3>
                <a href="javascript:history.back()" class="text-decoration-none">
                    < Back</a>
            </div>
        </div>
        <?php
            use App\Models\Advert;
        ?>
        <?php if(Advert::where(['user_id' => auth()->user()->id, 'draft' => true])->count() < 1): ?>
            <p class="text-danger text-center">No draft found</p>
        <?php else: ?>
            <div class="row mx-auto w-100 ">
                <?php $__currentLoopData = $adverts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-6 col-md-12 col-sm-12 col-12">

                        <div class="card w-100 mt-3 shadow-lg">
                            <div class="card-header d-flex justify-content-between">
                                <?php if($advert->service_id == null): ?>
                                    <p><?php echo e(ucfirst($advert->lodge->name)); ?></p>
                                <?php else: ?>
                                    <p><?php echo e(ucfirst($advert->service->name)); ?></p>
                                <?php endif; ?>
                                <p><?php echo e(ucfirst($advert->school_area->name)); ?></p>
                            </div>
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <?php if($advert->cover_image): ?>
                                        <img class="my-auto" src="<?php echo e(asset($advert->cover_image)); ?>"
                                            style="object-fit: cover; height: 200px" class="img-fluid" width="50%"
                                            alt="">
                                    <?php endif; ?>

                                    <div class="my-auto">
                                        <a href="<?php echo e(route('edit-draft', $advert->uuid)); ?>"><button
                                                class="btn btn-light btn-outline-success btn-sm ">Edit</button></a>
                                        <a href="<?php echo e(route('delete-draft', $advert->uuid)); ?>"
                                            onclick="event.preventDefault(); deleteDraft('<?php echo e(route('delete-draft', $advert->uuid)); ?>')"
                                            class="btn btn-danger btn-sm text-light">Delete</a>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer d-flex justify-content-between">
                                <p><?php echo e(ucfirst($advert->location->state)); ?></p>
                                <?php if($advert->combined_price !== null): ?>
                                <p>&#8358 <?php echo e(number_format($advert->combined_price)); ?></p>
                                <?php else: ?>
                                    Price on contact
                                <?php endif; ?>
                                
                            </div>

                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>

    <script>
        function deleteDraft(deleteUrl) {
            Swal.fire({
                title: 'Are you sure?',
                text: 'You are about to delete this draft',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = deleteUrl;
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\laravel\ark-project\resources\views/draft.blade.php ENDPATH**/ ?>