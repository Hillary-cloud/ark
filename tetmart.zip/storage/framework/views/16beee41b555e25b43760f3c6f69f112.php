<base href="/public">

<?php $__env->startSection('content'); ?>
    
    <div class="container">
        <div class="card w-100 m-3 shadow-sm p-2">
            <div class="d-flex justify-content-between">
                <h3 class="fw-bold">School</h3>
                <a href="<?php echo e(route('admin.add-school')); ?>" class="btn btn-success rounded-pill text-light p-1" style="width: 12rem">Add School</a>
            </div>
        </div>
        <div class="card w-100 p-2 m-3">

            <?php if(session('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
        <?php
            use App\Models\School;
        ?>
        <?php if(School::count() < 1): ?>
            <p class="text-danger text-center">No School found</p>
        <?php else: ?>
            <table class="table table-striped table-bordered table-hover text-center">
                <thead class="bg-success text-light">
                    <tr class="align-middle text-center">
                        <th>n/s</th>
                        <th>School</th>
                        <th>Slug</th>
                        <th>State</th>
                        <th>Edit</th>
                        <th>Remove</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $i = 1;
                    ?>
                    <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="align-middle text-center">
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e(ucfirst($school->name)); ?></td>
                        <td><?php echo e($school->slug); ?></td>
                        <td><?php echo e(ucfirst($school->location->state)); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.edit-school', $school->id)); ?>"><button class="btn btn-primary text-light">Edit</button></a>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.delete-school', $school->id)); ?>"
                                onclick="event.preventDefault(); deleteSchool('<?php echo e(route('admin.delete-school', $school->id)); ?>')"
                                class="btn btn-danger text-light">Delete</a>
                        </td>
                    </tr>        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function deleteSchool(deleteUrl) {
            Swal.fire({
                title: 'Are you sure?',
                text: 'You are about to delete this school',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = deleteUrl;
                }
            });
        }
        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\laravel\ark-project\resources\views/admin/school.blade.php ENDPATH**/ ?>