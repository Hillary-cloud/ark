<base href="/public">

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="card w-100 m-3 shadow-sm p-2">
            <div class="d-flex justify-content-between">
                <h3 class="fw-bold">Transactions</h3>
                <a href="javascript:history.back()" class="text-decoration-none">< Back</a>
            </div>
        </div>
        <div class="card w-100 p-2 m-3">
            <?php
                use App\Models\Payment;
            ?>
            <?php if(Payment::where('user_id',auth()->user()->id)->count() < 1): ?>
                <p class="text-danger text-center">No transaction yet</p>
            <?php else: ?>
                <table class="table table-striped table-bordered table-hover text-center">
                    <thead class="bg-success text-light">
                        <tr>
                            <th>Transaction Ref</th>
                            <th>Amount</th>
                            <th>Transaction Type</th>
                            <th>Transaction Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($payment->reference_number); ?></td>
                                <td><?php echo e($payment->amount); ?></td>
                                <td><?php echo e($payment->payment_for); ?></td>
                                <td><?php echo e($payment->created_at); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            <?php endif; ?>
            </div>
        </div>
    </div>
        
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\laravel\ark-project\resources\views/payment-history.blade.php ENDPATH**/ ?>