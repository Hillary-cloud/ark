<base href="/public">

<?php $__env->startSection('content'); ?>

<style>
    /* Add your CSS styles here */
    #back-to-top {
        display: none;
        position: fixed;
        bottom: 100px;
        right: 20px;
        background-color: green;
        color: white;
        border: none;
        border-radius: 50%;
        padding: 10px;
        cursor: pointer;
    }

    #back-to-top.show {
        display: block;
    }

</style>

    <div class="container my-4">
        <div class="d-flex justify-content-between">
            <h3 class="fw-bold">Listed Services</h3>
            <a href="javascript:history.back()" class="text-decoration-none">< Back</a>
        </div>
        
        <form action="<?php echo e(route('view-more-services')); ?>" method="GET" class="row g-3">

            <div class="col-2">
                <label for="service" class="form-label">Service</label><br>
                <select style="width: 100%" name="service" id="service">
                    <option value="">Service</option>
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($service->slug); ?>" <?php echo e(Request::get('service') == $service->slug ? 'selected' : ''); ?>>
                            <?php echo e(ucfirst($service->name)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-2">
                <label for="school" class="form-label">School</label><br>
                <select style="width: 100%" name="school" id="school">
                    <option value="">School</option>
                    <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($school->slug); ?>" <?php echo e(Request::get('school') == $school->slug ? 'selected' : ''); ?>>
                            <?php echo e(ucfirst($school->name)); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-2">
                <label for="school_area" class="form-label">Area</label><br>
                <select style="width: 100%" name="school_area" id="school_area">
                    <option value="">School Area</option>
                    <?php $__currentLoopData = $school_areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school_area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($school_area->slug); ?>" <?php echo e(Request::get('school_area') == $school_area->slug ? 'selected' : ''); ?>>
                            <?php echo e(ucfirst($school_area->name)); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-2">
                <label for="location" class="form-label">Location</label><br>
                <select style="width: 100%" name="location" id="location">
                    <option value="">Location</option>
                    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($location->slug); ?>" <?php echo e(Request::get('location') == $location->slug ? 'selected' : ''); ?>>
                            <?php echo e(ucfirst($location->state)); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="">
                <button type="submit" class="btn btn-success btn-sm"><i class="bi bi-funnel"></i> Filter</button>
            </div>

        </form>

        <div class="row d-flex justify-content-start" style="margin-bottom: 100px">
            <?php if($ads->count() > 0): ?>
                <p class="text-muted fst-italic">(<?php echo e($ads->count()); ?> ad<?php echo e($ads->count() !== 1 ? 's' : ''); ?>)</p>

                <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-4 col-sm-6 col-12 my-4">
                        <a href="<?php echo e(route('service-detail', $advert->uuid)); ?>" class="text-decoration-none">
                            <div class="card shadow-lg">
                                <img src="<?php echo e(asset($advert->cover_image)); ?>" class="card-img-top w-100"
                                    style="object-fit: cover; height:25vh" alt="">
                        </a>
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <h4 class="card-tittle fw-bold text-dark "><?php echo e(ucfirst($advert->service->name)); ?></h4>
                                <?php if(auth()->guard()->check()): ?>
                                    <a href="#"
                                        class="bookmark-button <?php echo e($advert->isBookmarkedByUser(Auth::user()) ? 'bookmarked' : ''); ?>"
                                        data-ad-id="<?php echo e($advert->id); ?>">
                                        <i class="bi bi-bookmark-fill" style="font-size: 25px"></i>
                                    </a>
                                <?php endif; ?>

                            </div>

                            <div class="d-flex justify-content-between">
                                <p class="card-text fw-bold bg-success p-2 rounded-pill text-light w-52 text-center">&#8358
                                    <?php echo e(number_format($advert->combined_price)); ?></p>
                                <p class="card-text "><small
                                        class="text-muted"><i class="bi bi-geo-alt"></i><?php echo e(ucfirst($advert->location->state)); ?></small>
                                </p>
                            </div>

                            <div class="d-flex justify-content-between mb-0">
                                <p class="card-text fw-bold text-dark"><i class="bi bi-bank2"></i> <?php echo e(ucfirst($advert->school->name)); ?></p>
                                <p class="card-text text-dark"><?php echo e(ucfirst($advert->school_area->name)); ?></p>
                            </div>
                            <div class="d-flex justify-content-between">
                                <p class="card-text "><small class="text-muted">Listed
                                        <?php echo e($advert->updated_at->diffForHumans()); ?></small></p>
                                <i class="bi bi-eye"> <?php echo e($advert->view_count); ?></i>
                            </div>
                        </div>
                    </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="pagination">
                <style>
                    nav svg {
                        height: 20px;
                    }

                    nav .hidden {
                        display: block !important;
                    }
                </style>
                <?php echo e($ads->links()); ?>

            </div>
        <?php else: ?>
            <p class="text-danger text-center">No ad found</p>
        <?php endif; ?>

    </div>

    <button id="back-to-top" class="show"><i class="bi bi-arrow-up"></i></button>

    <script>
        const backToTopButton = document.getElementById('back-to-top');
    
        // Show/hide the button based on scroll position
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                backToTopButton.classList.add('show');
            } else {
                backToTopButton.classList.remove('show');
            }
        });
    
        // Scroll smoothly to the top when the button is clicked
        backToTopButton.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    </script>
    

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const bookmarkButtons = document.querySelectorAll('.bookmark-button');

            bookmarkButtons.forEach(button => {
                button.addEventListener('click', function(event) {
                    event.preventDefault();
                    const adId = this.dataset.adId;
                    toggleBookmark(adId, this);
                });
            });
        });

        function toggleBookmark(adId, button) {
            axios.post('<?php echo e(route('bookmark.toggle')); ?>', {
                    advert_id: adId
                })
                .then(response => {
                    if (response.data.message === 'Ad bookmarked') {
                        button.classList.add('bookmarked');
                    } else {
                        button.classList.remove('bookmarked');
                    }
                })
                .catch(error => {
                    console.error(error);
                });
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\laravel\ark-project\resources\views/more-services.blade.php ENDPATH**/ ?>