<base href="/public">

<?php $__env->startSection('content'); ?>

<style>
    /* Add your CSS styles here */
    #back-to-top {
        display: none;
        position: fixed;
        bottom: 100px;
        right: 20px;
        background-color: green;
        color: white;
        border: none;
        border-radius: 50%;
        padding: 10px;
        cursor: pointer;
    }

    #back-to-top.show {
        display: block;
    }

    nav svg{
        height: 20px;
    }
    nav .hidden{
        display: block !important;
    }
            
</style>

    <div class="container" style="margin-bottom: 100px">

        <div class="card w-100 mt-3 shadow-sm p-2">
            <div class="d-flex justify-content-between">
                <h3 class="fw-bold">Ads</h3>
                <form class=" d-flex">
                    <input class=" me-2" style="width: 30vw;" type="search" name="query" value="<?php echo e(old('query', $query)); ?>" placeholder="Search" aria-label="Search" >
                    <button class="btn btn-outline-light btn-success form-control-lg" type="submit"><i class="bi bi-search" style="font-size: 20px"></i></button>
                </form>
            </div>
            <?php if($adverts->isEmpty()): ?>
            <p class="text-danger text-center">Nothing was found.</p>
            <?php endif; ?>
        </div>
        <div class="card w-100 p-2 mt-3">
            <?php if(session('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
            <?php
                use App\Models\Advert;
            ?>
            <?php if(Advert::count() < 1): ?>
                <p class="text-danger text-center">No ad found</p>
            <?php else: ?>
            <div class="row">
                <div class="col-12">
                    <table class="table table-striped table-bordered table-hover text-center">
                        <thead class="bg-success text-light">
                            <tr class="align-middle">
                                <th>n/s</th>
                                <th>Image</th>
                                <th>Ads</th>
                                <th>School</th>
                                <th>Status</th>
                                <th>View</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $i = 1;
                            ?>
                            <?php $__currentLoopData = $adverts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="align-middle">
                                    <td><?php echo e($i++); ?></td>
                                    <td><img src="<?php echo e(asset($advert->cover_image)); ?>" class="img-fluid" style="object-fit: cover; width:10vw; height:10vh" alt=""></td>
                                    <?php if($advert->service_id !== null): ?>
                                    <td><?php echo e(ucfirst($advert->service->name)); ?></td>
                                    <?php else: ?>
                                    <td><?php echo e(ucfirst($advert->lodge->name)); ?></td>
                                    <?php endif; ?>
                                    
                                    <td><?php echo e(ucfirst($advert->school->name)); ?></td>
                                    <?php if($advert->expiration_date == null && $advert->draft == false && $advert->active == false): ?>
                                        <td class="text-danger fst-italic">De-listed</td>
                                    <?php else: ?>
                                        <td class="text-success fst-italic">Listed</td>
                                    <?php endif; ?>
                                    <td>
                                        <a href="<?php echo e(route('admin.view-ad',$advert->uuid)); ?>"><button class="btn btn-success btn-sm text-light">View</button></a>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.delete-ad', $advert->uuid)); ?>"
                                            onclick="event.preventDefault(); deleteAdByAdmin('<?php echo e(route('admin.delete-ad', $advert->uuid)); ?>')"
                                            class="btn btn-danger btn-sm text-light">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
                        </tbody>
                    </table>
                </div>
            </div>
                
            <?php endif; ?>
            <div class="pagination">
                <?php echo e($adverts->links()); ?>

            </div>
        </div>
    </div>

    <button id="back-to-top" class="show"><i class="bi bi-arrow-up"></i></button>

    <script>
        const backToTopButton = document.getElementById('back-to-top');
    
        // Show/hide the button based on scroll position
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                backToTopButton.classList.add('show');
            } else {
                backToTopButton.classList.remove('show');
            }
        });
    
        // Scroll smoothly to the top when the button is clicked
        backToTopButton.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    </script>

    <script>
        function deleteAdByAdmin(deleteUrl) {
            Swal.fire({
                title: 'Are you sure?',
                text: 'You are about to delete this ad',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = deleteUrl;
                }
            });
        }
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\laravel\ark-project\resources\views/admin/all-ads.blade.php ENDPATH**/ ?>