<form action="<?php echo e(route('view-more-lodges')); ?>" method="GET" id="filter-form">
    <div class="mb-3">
    <select style="width:70px" name="lodge" id="lodge">
        <option value="">Lodge</option>
        <?php $__currentLoopData = $lodges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lodge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($lodge->id); ?>" <?php echo e(Request::get('lodge_id') == $lodge->id ? 'selected' : ''); ?>><?php echo e(ucfirst($lodge->name)); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <select style="width:70px" name="school" id="school">
        <option value="">School</option>
        <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($school->id); ?>" <?php echo e(Request::get('school_id') == $school->id ? 'selected' : ''); ?>><?php echo e(ucfirst($school->name)); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
    </select>
    <select style="width: 60px" name="price" id="price">
        <option value="">Price</option>
        <option value="0-50000" <?php echo e(Request::get('0-50000') == 0-50000 ? 'selected' : ''); ?>>&#8358 0 - &#8358 50,000</option>
        <option value="50001-100000" <?php echo e(Request::get('50001-100000') == 50001-100000 ? 'selected' : ''); ?>>&#8358 50,001 - &#8358 100,000</option>
        <option value="100001-150000" <?php echo e(Request::get('100001-150000') == 100001-150000 ? 'selected' : ''); ?>>&#8358 100,001 - &#8358 150,000</option>
        <option value="150001-200000" <?php echo e(Request::get('150001-200000') == 150001-200000 ? 'selected' : ''); ?>>&#8358 150,001 - &#8358 200,000</option>
        <option value="200001-100000000000" <?php echo e(Request::get('200001-100000000000') == 200001-100000000000 ? 'selected' : ''); ?>>&#8358 200,001 and above</option>
    </select>
</div>
<div class="mb-3">
    <select style="width:110px" name="school_area" id="school_area">
        <option value="">School Area</option>
        <?php $__currentLoopData = $school_areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school_area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($school_area->id); ?>" <?php echo e(Request::get('school_area_id') == $school_area->id ? 'selected' : ''); ?>><?php echo e(ucfirst($school_area->name)); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </select>
   
    <select style="width:85px" name="location" id="location">
        <option value="">Location</option>
        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($location->id); ?>" <?php echo e(Request::get('location_id') == $location->id ? 'selected' : ''); ?>><?php echo e(ucfirst($location->state)); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div>
    <button type="button" class="btn btn-success btn-sm" id="filter-button"><i class="bi bi-funnel"></i> Filter</button>
</div>
</form><?php /**PATH C:\Users\USER\Desktop\laravel\ark-project\resources\views/filter-form.blade.php ENDPATH**/ ?>