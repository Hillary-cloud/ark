<div class="row d-flex justify-content-start" style="margin-bottom: 100px" id="filtered-results">
    <?php if($adverts->count() > 0): ?>

        <p class="text-muted fst-italic">(<?php echo e($adverts->count()); ?> ad<?php echo e($adverts->count() !== 1 ? 's' : ''); ?>)</p>

        <?php $__currentLoopData = $adverts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-4 col-sm-6 col-12 my-4">
                <a href="<?php echo e(route('property-detail', $advert->uuid)); ?>" class="text-decoration-none">
                    <div class="card shadow-lg">
                        <img src="<?php echo e(asset($advert->cover_image)); ?>" class="card-img-top w-100"
                            style="object-fit: cover; height:25vh" alt="">
                </a>
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h4 class="card-tittle fw-bold text-dark "><?php echo e(ucfirst($advert->lodge->name)); ?></h4>
                        <?php if(auth()->guard()->check()): ?>
                            <a href="#"
                                class="bookmark-button <?php echo e($advert->isBookmarkedByUser(Auth::user()) ? 'bookmarked' : ''); ?>"
                                data-ad-id="<?php echo e($advert->id); ?>">
                                <i class="bi bi-bookmark-fill" style="font-size: 25px"></i>
                            </a>
                        <?php endif; ?>

                    </div>

                    <div class="d-flex justify-content-between">
                        <p class="card-text fw-bold bg-success p-2 rounded-pill text-light w-52 text-center">&#8358
                            <?php echo e(number_format($advert->combined_price)); ?></p>
                        <p class="card-text "><small class="text-muted"><?php echo e(ucfirst($advert->location->state)); ?></small>
                        </p>
                    </div>

                    <div class="d-flex justify-content-between mb-0">
                        <p class="card-text fw-bold text-dark"><?php echo e(ucfirst($advert->school->name)); ?></p>
                        <p class="card-text text-dark"><?php echo e(ucfirst($advert->school_area->name)); ?></p>
                    </div>
                    <div class="d-flex justify-content-between">
                        <p class="card-text "><small class="text-muted">Listed
                                <?php echo e($advert->created_at->diffForHumans()); ?></small></p>
                        <i class="bi bi-eye"> <?php echo e($advert->view_count); ?></i>
                    </div>
                </div>
            </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php else: ?>
<p class="text-danger text-center">No ad found</p>
<?php endif; ?>

</div>
</div>
<?php /**PATH C:\Users\USER\Desktop\laravel\ark-project\resources\views/partials/advert_list.blade.php ENDPATH**/ ?>