<a class="nav-link" href="<?php echo e(route('notifications.index')); ?>">
    <i class="bi bi-bell-fill"></i>
    <?php if(auth()->user()->unreadNotifications->count() > 0): ?>
        <span class="badge badge-danger"><?php echo e(auth()->user()->unreadNotifications->count()); ?></span>
    <?php endif; ?>
</a><?php /**PATH C:\Users\USER\Desktop\laravel\ark-project\resources\views/notification-menu.blade.php ENDPATH**/ ?>