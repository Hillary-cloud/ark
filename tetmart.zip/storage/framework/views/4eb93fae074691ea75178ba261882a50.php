<base href="/public">

<?php $__env->startSection('content'); ?>
    <div class="container w-75 mx-auto my-3">
        <div class="card p-2">
            <div class="d-flex justify-content-between">
                <h3>Re-list Ad</h3>
                <a href="javascript:history.back()" class="text-decoration-none">< Back</a>
            </div>
        </div>

        <div class="card shadow-sm my-2 p-3">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                    <div class="my-2">
                        <p><strong>Cover Image</strong></p> 
                        <img src="<?php echo e(asset($advert->cover_image)); ?>" class="img-fluid" style="object-fit: cover; width:15vw; height:15vh" alt="">
                    </div>
                    
                    <?php if($advert->other_images): ?>
                    <p><strong>Other Images</strong></p>
                        <?php $__currentLoopData = $advert->other_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e(asset($images)); ?>" class="img-fluid mb-2" style="object-fit: cover; width:8vw; height:8vh" alt="">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php if($advert->lodge_id !== null): ?>
                    <p><strong>Lodge</strong> - <?php echo e(ucfirst($advert->lodge->name)); ?></p>
                    <?php else: ?>
                    <p><strong>Service</strong> - <?php echo e(ucfirst($advert->service->name)); ?></p>
                    <?php endif; ?>
                    <p><strong>School Area</strong> - <?php echo e(ucfirst($advert->school_area->name)); ?></p>
                    <p><strong>School</strong> - <?php echo e(ucfirst($advert->School->name)); ?></p>
                    <p><strong>Location</strong> - <?php echo e(ucfirst($advert->location->state)); ?></p>
                    <p><strong>Description</strong> - <?php echo e(ucfirst($advert->description)); ?></p>
                    <p><strong>Name</strong> - <?php echo e(ucfirst($advert->seller_name)); ?></p>
                    
                    
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                    <?php if($advert->lodge_id !== null): ?>
                    <form action="<?php echo e(route('update-relist-lodge',$advert->uuid)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <div class="mb-3">
                            <label for="price" class="form-label">Price(&#8358)<span class="text-danger">*</span></label>
                            <input type="number" name="price" id="price" value="<?php echo e($advert->price); ?>"
                                class="form-control" step="0.01">
                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    
                    <div class="mb-3">
                        <label for="agent_fee" class="form-label">Agent fee(&#8358)</label>
                        <input type="number" name="agent_fee" id="agent_fee" value="<?php echo e($advert->agent_fee); ?>"
                            class="form-control" step="0.01">
                        <?php $__errorArgs = ['agent_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-check mb-3">
                        <input type="checkbox" name="negotiable" value="<?php echo e($advert->negotiable); ?>"
                            id="negotiable" class="form-check-input">
                        <label for="negotiable" class="form-check-label">Negotiable</label>
                        <?php $__errorArgs = ['negotiable'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="phone_number" class="form-label">Phone number<span class="text-danger">*</span></label>
                        <input type="text" name="phone_number" id="phone_number"
                            value="<?php echo e($advert->phone_number); ?>"
                            class="form-control">
                            <p class="text-muted fst-italic">NB: Provide your active phone number as people will reach out to you through it.</p>
                        <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <button class=" btn btn-primary btn-lg mx-auto w-100">Re-list Lodge</button>
                </form>

                <?php else: ?>
                <form action="<?php echo e(route('update-relist-service',$advert->uuid)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="mb-3">
                        <label for="price" class="form-label">Price(&#8358)</label>
                        <input type="number" name="price" id="price"
                            class="form-control" onchange="handleInputToggle()" step="0.01">
                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <div class="form-check mb-3">
                    <input type="checkbox" name="on_contact"
                        id="onContact" class="form-check-input" onchange="handleInputToggle()" value="1" <?php if($advert->on_contact): ?> checked <?php endif; ?>>
                    <label for="on_contact" class="form-check-label">On Contact</label>
                    <?php $__errorArgs = ['on_contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3">
                    <label for="phone_number" class="form-label">Phone number<span class="text-danger">*</span></label>
                    <input type="text" name="phone_number" id="phone_number"
                        value="<?php echo e($advert->phone_number); ?>"
                        class="form-control">
                        <p class="text-muted fst-italic">NB: Provide your active phone number as people will reach out to you through it.</p>
                    <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button class=" btn btn-primary btn-lg mx-auto w-100">Re-list Service</button>
            </form>
                <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        function handleInputToggle() {
          const priceInput = document.getElementById('price');
          const onContactInput = document.getElementById('onContact');
        
          if (onContactInput.checked) {
            priceInput.value = ''; // Clear the value
            priceInput.disabled = true; // Disable the field
          } else if (priceInput.value !== '') {
            onContactInput.disabled = true; // Disable the checkbox
          } else {
            priceInput.disabled = false; // Enable the field
            onContactInput.disabled = false; // Enable the checkbox
          }
        }
            </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\laravel\ark-project\resources\views/relist.blade.php ENDPATH**/ ?>