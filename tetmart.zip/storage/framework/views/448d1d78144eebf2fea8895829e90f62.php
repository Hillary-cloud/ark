<base href="/public">

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-lg-8 col-md-8 col-sm-12 col-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h5>Ad Details</h5>
                        <a href="javascript:history.back()" class="text-decoration-none">
                            < Back</a>
                    </div>

                    <div class="card-body">
                        <?php if(isset($errorMessage)): ?>
                            <div class="alert alert-danger">
                                <?php echo e($errorMessage); ?>

                            </div>
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                                <?php if($advert->service_id !== null): ?>
                                    <p><strong>Service:</strong> <?php echo e(ucfirst($advert->service->name)); ?></p>
                                <?php else: ?>
                                    <p><strong>Lodge:</strong> <?php echo e(ucfirst($advert->lodge->name)); ?></p>
                                <?php endif; ?>

                                <p><strong>Location:</strong> <?php echo e(ucfirst($advert->location->state)); ?></p>
                                <p><strong>School:</strong> <?php echo e(ucfirst($advert->school->name)); ?></p>
                                <p><strong>School Area:</strong> <?php echo e(ucfirst($advert->school_area->name)); ?></p>
                                <?php if($advert->combined_price !== null): ?>
                                    <p><strong>Price:</strong> &#8358 <?php echo e(number_format($advert->combined_price)); ?></p>
                                <?php else: ?>
                                    <p><strong>Price:</strong> On Contact</p>
                                <?php endif; ?>

                                <p><strong>Phone:</strong> <?php echo e($advert->phone_number); ?></p>

                                <p><strong>Description:</strong> <?php echo e(ucfirst($advert->description)); ?></p>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="">
                                    <p><strong>Cover Image</strong></p>
                                    <img src="<?php echo e(asset($advert->cover_image)); ?>" class="img-fluid w-100 h-25"
                                        style="object-fit: cover;" alt="">
                                </div>

                                <?php if($advert->other_images): ?>
                                    <p><strong>Other Images</strong></p>
                                    <?php $__currentLoopData = $advert->other_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <img src="<?php echo e(asset($images)); ?>" class="img-fluid h-25 mb-2"
                                    style="width:23%; object-fit: cover;" alt="">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                                <form action="<?php echo e(route('post', $advert->uuid)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>

                                    

                                    <button type="submit" class="btn btn-primary w-100">Post</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\laravel\ark-project\resources\views/post-ad-page.blade.php ENDPATH**/ ?>