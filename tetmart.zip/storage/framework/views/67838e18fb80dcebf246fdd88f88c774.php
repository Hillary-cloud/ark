

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>404 Error</h1>
        <p>Ad not found. Please check the URL or try again later.</p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\laravel\ark-project\resources\views/errors/404.blade.php ENDPATH**/ ?>