<base href="/public">



<?php $__env->startSection('content'); ?>
<style>
    /* Add this CSS class to change the color of read notifications */
.read-notification {
    color: #888; /* Change this color to the desired color for read notifications */
}

</style>
<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Notifications</div>

                <div class="card-body">
                    <?php if(count($notifications) > 0): ?>
                        <ul class="list-group ">
                            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item ">
                                    <a class="text-decoration-none <?php echo e($notification->read_at ? 'read-notification' : ''); ?> notification-link " data-notification-id="<?php echo e($notification->id); ?>" href="<?php echo e(route('view-my-ad', $notification->data['ad_uuid'])); ?>"><?php echo e($notification->data['message']); ?></a>
                                    <p class="text-muted"><?php echo e($notification->created_at->diffForHumans()); ?></p>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php else: ?>
                        <p>No notifications.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const notificationLinks = document.querySelectorAll('.notification-link');

        notificationLinks.forEach(link => {
            link.addEventListener('click', function (e) {
                e.preventDefault();

                const notificationId = link.getAttribute('data-notification-id');

                // Send an AJAX request to mark the notification as read
                fetch("<?php echo e(url('/mark-notification-as-read')); ?>/" + notificationId, {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>",
                        'Content-Type': 'application/json',
                    },
                })
                .then(response => {
                    if (response.ok) {
                        // Add the read-notification class to change the color
                        link.classList.add('read-notification');
                        // Redirect to the notification target URL or handle it as needed
                        window.location.href = link.getAttribute('href');
                    }
                })
                .catch(error => {
                    console.error(error);
                });
            });
        });
    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\laravel\ark-project\resources\views/notification.blade.php ENDPATH**/ ?>