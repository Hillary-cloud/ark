<base href="/public">

<?php $__env->startSection('content'); ?>
    
    <div class="container">
        <div class="card w-100 m-3 shadow-sm p-2">
            <div class="d-flex justify-content-between">
                <h3 class="fw-bold">Add Service</h3>
                <a href="<?php echo e(route('admin.service')); ?>" class="btn btn-success rounded-pill text-light p-1" style="width: 12rem">All Service</a>
            </div>
        </div>
        <div class="card p-2 m-3 shadow-lg mx-auto ">
            <?php if(session('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
            <form action="<?php echo e(route('admin.store-service')); ?>" method="POST" class="p-3">
                <?php echo csrf_field(); ?>
                <label for="">Service</label>
                <input type="text" name="name" id="name" class="form-control" placeholder="add service name">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label for="">Slug</label>
                <input type="text" name="slug" id="slug" class="form-control" placeholder="add slug">
                <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <button class="btn btn-success mt-2">Submit</button>
            </form>
        </div>
    </div>
    
    <script src="<?php echo e(asset('js/slug.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\laravel\ark-project\resources\views/admin/add-service.blade.php ENDPATH**/ ?>