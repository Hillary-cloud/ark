<base href="/public">

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card w-100 m-3 shadow-sm p-2">
            <div class="d-flex justify-content-between">
                <h3 class="fw-bold">Edit School</h3>
                <a href="<?php echo e(route('admin.school')); ?>" class="btn btn-success rounded-pill text-light p-1"
                    style="width: 12rem">All School</a>
            </div>
        </div>
        <div class="card w-50 p-2 m-3 shadow-lg mx-auto ">
            <?php if(session('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
            <form action="<?php echo e(route('admin.update-school', $school->id)); ?>" method="post" class="p-3">
                <?php echo method_field('put'); ?>
                <?php echo csrf_field(); ?>

                <label class="" for="">State</label>

                <input type="text" name="" class="form-control" value="<?php echo e(ucfirst($school->location->state)); ?>"
                    readonly>
                <input type="hidden" name="location_id" value="<?php echo e($school->location_id); ?>">

                <label for="">School name</label>
                <input type="text" name="name" id="name" value="<?php echo e(ucfirst($school->name)); ?>" class="form-control">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <label for="">Slug</label>
                <input type="text" name="slug" id="slug" value="<?php echo e($school->slug); ?>" class="form-control">
                <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <button class="btn btn-success mt-2">Update</button>
            </form>
        </div>
    </div>

    <script src="<?php echo e(asset('js/slug.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\laravel\ark-project\resources\views/admin/edit-school.blade.php ENDPATH**/ ?>