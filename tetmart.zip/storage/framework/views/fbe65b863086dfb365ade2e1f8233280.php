<base href="/public">

<?php $__env->startSection('content'); ?>
    <style>
        /* CSS Styling for the image previews */
        #otherImagesPreview {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-evenly;
        }

        .imagePreview {
            margin: 10px;
            text-align: center;
        }

        .imagePreview img {
            display: block;
            margin-bottom: 5px;
        }
        #imageContainer {
  display: flex;
  flex-wrap: wrap;
}

.added-image {
  width: 150px;
  height: 150px;
  margin: 10px;
}

    </style>
    <div class="container">
        <div class="card w-100 my-3 shadow-sm p-2">
            <div class="d-flex justify-content-between">
                <h3>Post Lodge</h3>
                <a href="javascript:history.back()" class="text-decoration-none">< Back</a>
            </div>
        </div>

        <div class="card w-100 mx-auto my-3 shadow-sm">
            <form action="<?php echo e(route('store-lodge')); ?>" class="p-4" method="POST" enctype="multipart/form-data" 
                id="postLodgeForm">
                <?php echo csrf_field(); ?>

                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                            <div class="mb-3">
                                <label for="lodge" class="form-label">Lodge<span class="text-danger">*</span></label>
                                <select class="form-control" name="lodge_id" id="lodge" onchange="generateSlug()">
                                    <option value="">Select Lodge</option>
                                    <?php $__currentLoopData = $lodges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lodge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($lodge->id); ?>"><?php echo e(ucfirst($lodge->name)); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['lodge_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <input type="hidden" id="slug" class="" name="slug">

                            <div class="mb-3">
                                <label for="location" class="form-label">Location<span class="text-danger">*</span></label>
                                <select class="form-control" name="location_id" id="location">
                                    <option value="">Select Location</option>
                                    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($location->id); ?>"><?php echo e(ucfirst($location->state)); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['location_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="school" class="form-label">School<span class="text-danger">*</span></label>
                                <select class="form-control" name="school_id" id="school" disabled>
                                    <option value="">Select School</option>
                                </select>
                                <?php $__errorArgs = ['school_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="school_area" class="form-label">School Area<span class="text-danger">*</span></label>
                                <select class="form-control" name="school_area_id" id="school_area" disabled>
                                    <option value="">Select School Area</option>
                                </select>
                                <?php $__errorArgs = ['school_area_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="cover_image" class="form-label">Cover Image<span class="text-danger">*</span></label>
                                <input type="file" name="cover_image" id="cover_image" accept="image/*"
                                    class="form-control">
                                <div id="coverImagePreview" class="mt-2"></div>
                                <?php $__errorArgs = ['cover_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="other_images" class="form-label">Other Images (not more than 4 images)</label>
                                <input type="file" name="other_images[]" id="other_images" accept="image/*"
                                    class="form-control" multiple max="4">
                                <div id="otherImagesPreview" class="mt-2"></div>
                                <?php $__errorArgs = ['other_images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
        
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                            <div class="mb-3">
                                <label for="price" class="form-label">Price(&#8358)<span class="text-danger">*</span></label>
                                <input type="number" name="price" id="price" value="<?php echo e(old('price')); ?>"
                                    class="form-control" step="0.01">
                                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="agent_fee" class="form-label">Agent fee(&#8358)</label>
                                <input type="number" name="agent_fee" id="agent_fee" value="<?php echo e(old('agent_fee')); ?>"
                                    class="form-control" step="0.01">
                                <?php $__errorArgs = ['agent_fee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-check mb-3">
                                <input type="checkbox" name="negotiable" value="<?php echo e(old('negotiable')); ?>"
                                    id="negotiable" class="form-check-input">
                                <label for="negotiable" class="form-check-label">Negotiable</label>
                                <?php $__errorArgs = ['negotiable'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="description" class="form-label">Description<span class="text-danger">*</span></label>
                                <textarea name="description" id="description" placeholder="Give a detailed description of the lodge" class="form-control"
                                    rows="3"><?php echo e(old('description')); ?></textarea>
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="phone_number" class="form-label">Phone number<span class="text-danger">*</span></label>
                                <input type="text" name="phone_number" id="phone_number"
                                    value="<?php echo e(old('phone_number')); ?>" placeholder="e.g, 080123456789"
                                    class="form-control">
                                    <p class="text-muted fst-italic">NB: Provide your active phone number as people will reach out to you through it.</p>
                                <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">

                            <div class="mb-3">
                                
                                <input type="text" name="seller_name" id="seller_name"
                                    value="<?php echo e(ucfirst(auth()->user()->name)); ?>" class="form-control" readonly>
                                <?php $__errorArgs = ['seller_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>

                    </div>
                    <button type="submit" class="btn btn-light btn-outline-success btn-lg w-100">Post Lodge</button>

                </div>

            </form>
        </div>
    </div>

<script src="<?php echo e(asset('js/script.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\laravel\ark-project\resources\views/post-lodge.blade.php ENDPATH**/ ?>