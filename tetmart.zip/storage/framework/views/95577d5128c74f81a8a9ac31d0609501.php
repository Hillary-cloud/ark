<base href="/public">

<?php $__env->startSection('content'); ?>
    payment
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\laravel\ark-project\resources\views/payment.blade.php ENDPATH**/ ?>