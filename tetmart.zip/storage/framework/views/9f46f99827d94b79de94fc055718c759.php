<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="icon" href="<?php echo e(asset('title-logo.jpg')); ?>" type="image/jpg" sizes="32X32">
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
   
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />    
    <link href="css/style.css" rel="stylesheet">
    <!-- Scripts -->
    
    
    <style>
        footer{
            padding: 10px;
            text-align: center;
            position: absolute;
            right: 0;
            left: 0;
            bottom: 0;
        }
        html{
            height: 100%;
            box-sizing: border-box;
        }
        body{
            position: relative;
            min-height: 100%;
            padding-bottom: 6rem;
            box-sizing: inherit;
        }
    </style>
    
</head>

<body style="overflow-x: hidden">
    <div id="app">
        <nav class="navbar navbar-expand-lg navbar-dark bg-success sticky-top">
            <div class="container-fluid">
                <a class="navbar-brand text ps-4 fw-bold" href="/"><img src="../loggo2.png" class="img-fluid" style="width: 150px" alt=""></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                   
                    <ul class="navbar-nav ms-auto mb-2 me-5 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="/">Home</a>
                        </li>
                        
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle btn-primary btn-sm fw-bold rounded-pill p-2 text-light" href="#" id="navbarDropdownn" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                Post Ad
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdownn">
                                <li><a class="dropdown-item" href="<?php echo e(route('postLodge')); ?>">Post Lodge</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="<?php echo e(route('postService')); ?>">Post Service</a></li>
                            </ul>
                        </li>

                        
                        <?php if(Route::has('login')): ?>
                            <?php if(auth()->guard()->check()): ?>
                                <?php if(Auth::user()->user_type === 'ADM'): ?>

                                <li class="nav-item">
                                    <a class="nav-link" aria-current="page" href="<?php echo e(route('notification')); ?>">
                                        <i class="bi bi-bell-fill" style="color: yellow"></i>
                                        <?php if(auth()->user()->unreadNotifications->count() > 0): ?>
                                        <span class="text-warning"><sup class="notification-count bg-warning text-danger fw-bold" style="border-radius: 50%; padding-left:5px; padding-right:5px;"><?php echo e(auth()->user()->unreadNotifications->count()); ?></sup></span>
                                    <?php endif; ?>
                                </a>
                                </li>

                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                        data-bs-toggle="dropdown" aria-expanded="false">
                                        Dashboard
                                    </a>
                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                        <li><a class="dropdown-item" href="<?php echo e(route('over-view')); ?>"><i class="bi bi-speedometer2"></i> Overview</a></li>
                                        <li>
                                            <hr class="dropdown-divider">
                                        </li>
                                        <li><a class="dropdown-item" href="<?php echo e(route('admin.all-ads')); ?>"><i class="bi bi-badge-ad-fill"></i> All Ads</a></li>
                                        <li>
                                            <hr class="dropdown-divider">
                                        </li>
                                        <li><a class="dropdown-item" href="<?php echo e(route('admin.lodge')); ?>"><i class="bi bi-house"></i> Lodge</a></li>
                                        <li>
                                            <hr class="dropdown-divider">
                                        </li>
                                        <li><a class="dropdown-item" href="<?php echo e(route('admin.service')); ?>"><i class="bi bi-tools"></i> Service</a></li>
                                        <li>
                                            <hr class="dropdown-divider">
                                        </li>
                                        <li><a class="dropdown-item" href="<?php echo e(route('admin.location')); ?>"><i class="bi bi-geo-alt"></i> Location</a></li>
                                        <li>
                                            <hr class="dropdown-divider">
                                        </li>
                                        <li><a class="dropdown-item" href="<?php echo e(route('admin.school')); ?>"><i class="bi bi-bank2"></i> School</a></li>
                                        <li>
                                            <hr class="dropdown-divider">
                                        </li>
                                        <li><a class="dropdown-item" href="<?php echo e(route('admin.school-area')); ?>"><i class="bi bi-houses"></i> School Area</a></li>
                                    
                                    </ul>
                                </li>
        
                                    <li class="nav-item dropdown">
                                        <a id="navbarDropdowni" class="nav-link dropdown-toggle" href="#"
                                            role="button" data-bs-toggle="dropdown" aria-haspopup="true"
                                            aria-expanded="false" v-pre>
                                            User(<?php echo e(explode(' ', trim( Auth::user()->name) )[0]); ?>)
                                        </a>

                                        
                                        <ul class="dropdown-menu" aria-labelledby="navbarDropdowni">
                                            <a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>"><i class="bi bi-person"></i> Profile</a>
                                            <li>
                                                <hr class="dropdown-divider">
                                            </li>
                                            <li><a class="dropdown-item" href="<?php echo e(route('my-ads')); ?>"><i class="bi bi-badge-ad"></i> My Ads</a></li>
                                            <li>
                                                <hr class="dropdown-divider">
                                            </li>
                                            <li><a class="dropdown-item" href="<?php echo e(route('draft')); ?>"><i class="bi bi-file-earmark"></i> Draft</a></li>
                                        <li>
                                            <hr class="dropdown-divider">
                                        </li>
                                        <li><a class="dropdown-item" href="<?php echo e(route('bookmarks')); ?>"><i class="bi bi-bookmark"></i> Saved</a></li>
                                        <li>
                                            <hr class="dropdown-divider">
                                        </li>
                                        <li><a class="dropdown-item" href="<?php echo e(route('payment-history')); ?>"><i class="bi bi-credit-card-2-back"></i> Transaction History</a></li>
                                        <li>
                                            <hr class="dropdown-divider">
                                        </li>
                                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                                onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                               <i class="bi bi-box-arrow-right"></i> <?php echo e(__('Logout')); ?>

                                            </a>

                                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                                class="d-none">
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        </ul>
                                        
                                    </li>
                                <?php else: ?>
                                
                                <li class="nav-item">
                                    <a class="nav-link" aria-current="page" href="<?php echo e(route('notification')); ?>">
                                        <i class="bi bi-bell-fill" style="color: yellow"></i>
                                        <?php if(auth()->user()->unreadNotifications->count() > 0): ?>
                                        <span class="text-warning"><sup class="notification-count bg-warning text-danger fw-bold" style="border-radius: 50%; padding-left:5px; padding-right:5px;"><?php echo e(auth()->user()->unreadNotifications->count()); ?></sup></span>
                                    <?php endif; ?>
                                </a>
                                </li>
                                
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownii" role="button"
                                            data-bs-toggle="dropdown" aria-expanded="false">
                                            Dashboard
                                        </a>
                                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownii">
                                            
                                            <li><a class="dropdown-item" href="<?php echo e(route('my-ads')); ?>"><i class="bi bi-badge-ad"></i> My Ads</a></li>
                                            <li>
                                                <hr class="dropdown-divider">
                                            </li>
                                            <li><a class="dropdown-item" href="<?php echo e(route('draft')); ?>"><i class="bi bi-file-earmark"></i> Draft</a></li>
                                            <li>
                                                <hr class="dropdown-divider">
                                            </li>
                                            <li><a class="dropdown-item" href="<?php echo e(route('bookmarks')); ?>"><i class="bi bi-bookmark"></i> Saved</a></li>
                                            <li>
                                                <hr class="dropdown-divider">
                                            </li>
                                            <li><a class="dropdown-item" href="<?php echo e(route('payment-history')); ?>"><i class="bi bi-credit-card-2-back"></i> Transaction History</a></li>

                                        </ul>
                                    </li>
                                    
                                    <li class="nav-item dropdown">
                                        <a id="navbarDropdowniii" class="nav-link dropdown-toggle" href="#"
                                            role="button" data-bs-toggle="dropdown" aria-haspopup="true"
                                            aria-expanded="false" v-pre>
                                            User(<?php echo e(explode(' ', trim( Auth::user()->name) )[0]); ?>)
                                        </a>

                                        
                                        <ul class="dropdown-menu" aria-labelledby="navbarDropdowniii">
                                            <a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>"><i class="bi bi-person"></i> Profile</a>
                                            <li>
                                                <hr class="dropdown-divider">
                                            </li>
                                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                                onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                               <i class="bi bi-box-arrow-right"></i> <?php echo e(__('Logout')); ?>

                                            </a>

                                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                                class="d-none">
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        </ul>
                                        
                                    </li>
                                <?php endif; ?>
                            <?php else: ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>

                                <?php if(Route::has('register')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php endif; ?>

                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <?php echo $__env->yieldContent('content'); ?>

        <footer class="bg-success">
            <div class="container" >
              <div class="row mt-3">
                <div class="col-md-6">
                  <p class="text-light">&copy; <script>document.write(new Date().getFullYear())</script> Tetmart. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-md-end ">
                  <p>
                    <a style="color: black" href="#"><i class="bi bi-instagram"></i> </a>
                     <a class="mx-3" style="color: black" href="#"><i class="bi bi-twitter"></i></a>
                    <a style="color: black" href="#"><i class="bi bi-facebook"></i></a>
                </p>
                </div>
              </div>
            </div>
          </footer>
        
    </div>
   
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.min.js"></script>
    <script src="<?php echo e(asset('js/share.js')); ?>"></script>

    
    
    
    
    
</body>

</html>
<?php /**PATH C:\Users\USER\Desktop\laravel\ark-project\resources\views/layouts/base.blade.php ENDPATH**/ ?>